"""tiger-id: stripe-pattern tiger identification via LLM vision."""

__version__ = "0.1.0"
